//---------------------------------------------------------------------------


#pragma hdrstop

#include <math.h>
#include "ML_Vector.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)

float CVector2f::Length()
{
  return (float) sqrt((X*X)+(Y*Y));
};

CVector2f CVector2f::Normalize()
{
  float len = Length();

  if (len != 0.0f) return CVector2f(X/len, Y/len);
  else return CVector2f(X, Y);
}


float CVector3f::Length()
{
  return (float) sqrt((X*X)+(Y*Y)+(Z*Z));
};

CVector3f CVector3f::Normalize()
{
  float len = Length();

  if (len != 0.0f) return CVector3f(X/len, Y/len, Z/len);
  else return CVector3f(X, Y, Z);
}

CVector3f CVector3f::DotProduct(const CVector3f& vet)
{
  return CVector3f((X*vet.Z)+(Z*vet.Y), (Z*vet.X)+(X*vet.Z), (X*vet.Y)+(Y*vet.X));
}

CVector3f CVector3f::CrossProduct(const CVector3f& vet)
{
  return CVector3f((Y*vet.Z)-(Z*vet.Y), (Z*vet.X)-(X*vet.Z), (X*vet.Y)-(Y*vet.X));
}

