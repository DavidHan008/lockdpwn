#ifndef ML_VectorH
#define ML_VectorH

//---------------------------------------------------------------------------
class CVector2f
{
public:
  union
  {
    float array[2];
    struct { float X, Y; };
  };

  CVector2f() {};
  CVector2f(float _X, float _Y)
  {
    X = _X;
    Y = _Y;
  };

  void Set(float _X=0.0f, float _Y=0.0f)
  {
    X = _X;
    Y = _Y;
  };

  inline float Length();
  CVector2f Normalize();
};

//---------------------------------------------------------------------------
class CVector3f
{
public:
  union
  {
    float arraY[3];
    struct { float X, Y, Z; };
  };

  CVector3f() {};
  CVector3f(float _X, float _Y, float _Z)
  {
    X = _X;
    Y = _Y;
    Z = _Z;
  };

  void Set(float _X=0.0f, float _Y=0.0f, float _Z=0.0f)
  {
    X = _X;
    Y = _Y;
    Z = _Z;
  };

  inline float Length();
  
  CVector3f Normalize();
  CVector3f DotProduct(const CVector3f& vet);   //���� ����
  CVector3f CrossProduct(const CVector3f& vet); //���� ����
};

//---------------------------------------------------------------------------
class CVector4f
{
public:
  union{
    float arraY[4];
    struct { float X, Y, Z, W; };
  };
  CVector4f() {};
  CVector4f(float _X, float _Y, float _Z, float _W)
  {
    X = _X;
    Y = _Y;
    Z = _Z;
    W = _W;
  };
  void Set(float _X=0.0f, float _Y=0.0f, float _Z=0.0f, float _W=0.0f)
  {
    X = _X;
    Y = _Y;
    Z = _Z;
    W = _W;
  };
};

//---------------------------------------------------------------------------
CVector2f operator +(const CVector2f& v1, const CVector2f& v2)
{
  return CVector2f(v1.X+v2.X, v1.Y+v2.Y);
}

CVector2f operator -(const CVector2f& v1, const CVector2f& v2)
{
  return CVector2f(v1.X-v2.X, v1.Y-v2.Y);
}

CVector2f operator *(const CVector2f& v1, const CVector2f& v2)
{
  return CVector2f(v1.X*v2.X, v1.Y*v2.Y);
}

CVector2f operator /(const CVector2f& v1, const CVector2f& v2)
{
  return CVector2f(v1.X/v2.X, v1.Y/v2.Y);
}

CVector2f operator +(const CVector2f& v1, float v2)
{
  return CVector2f(v1.X+v2, v1.Y+v2);
}

CVector2f operator -(const CVector2f& v1, float v2)
{
  return CVector2f(v1.X-v2, v1.Y-v2);
}

CVector2f operator *(const CVector2f& v1, float v2)
{
  return CVector2f(v1.X*v2, v1.Y*v2);
}

CVector2f operator /(const CVector2f& v1, float v2)
{
  return CVector2f(v1.X/v2, v1.Y/v2);
}

//---------------------------------------------------------------------------
CVector3f operator +(const CVector3f& v1, const CVector3f& v2)
{
  return CVector3f(v1.X+v2.X, v1.Y+v2.Y, v1.Z+v2.Z);
}

CVector3f operator -(const CVector3f& v1, const CVector3f& v2)
{
  return CVector3f(v1.X-v2.X, v1.Y-v2.Y, v1.Z-v2.Z);
}

CVector3f operator *(const CVector3f& v1, const CVector3f& v2)
{
  return CVector3f(v1.X*v2.X, v1.Y*v2.Y, v1.Z*v2.Z);
}

CVector3f operator /(const CVector3f& v1, const CVector3f& v2)
{
  return CVector3f(v1.X/v2.X, v1.Y/v2.Y, v1.Z/v2.Z);
}

CVector3f operator +(const CVector3f& v1, float v2)
{
  return CVector3f(v1.X+v2, v1.Y+v2, v1.Z+v2);
}

CVector3f operator -(const CVector3f& v1, float v2)
{
  return CVector3f(v1.X-v2, v1.Y-v2, v1.Z-v2);
}

CVector3f operator *(const CVector3f& v1, float v2)
{
  return CVector3f(v1.X*v2, v1.Y*v2, v1.Z*v2);
}

CVector3f operator /(const CVector3f& v1, float v2)
{
  return CVector3f(v1.X/v2, v1.Y/v2, v1.Z/v2);
}


#endif
