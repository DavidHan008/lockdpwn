#ifndef ML_MATRIX_H
#define ML_MATRIX_H

#include "ML_Vector.h"

///
struct CMatrix22
{
    union
    {
        struct
        {
            float array[4];
        };
        struct
        {
            float _11, _12,
                  _21, _22;
        };
    };

    CMatrix22();
    CMatrix22(float m11, float m12,
              float m21, float m22);
    void IdenCMatrix();
    void ZeroCMatrix();
    CMatrix22 operator +(const CMatrix22 &mat) const;
    CMatrix22 operator -(const CMatrix22 &mat) const;
    CMatrix22 operator *(const CMatrix22 &mat) const;
    CMatrix22 Tran();         // ��ġ���
    float Det();              // ��Ľ�
    CMatrix22 Inverse();      // �����
};

///
struct CMatrix33
{
    union
    {
        struct
        {
            float array[9];
        };
        struct
        {
            float _11, _12, _13,
                  _21, _22, _23,
                  _31, _32, _33;
        };
    };
    CMatrix33();
    CMatrix33(float m11, float m12, float m13,
              float m21, float m22, float m23,
              float m31, float m32, float m33);
    void IdenCMatrix();
    void ZeroCMatrix();
    CMatrix33 operator +(const CMatrix33 &mat) const;
    CMatrix33 operator -(const CMatrix33 &mat) const;
    CMatrix33 operator *(const CMatrix33 &mat) const;
    CVector3f operator *(const CVector3f &vet) const;
    CMatrix33 Tran();
    float Det();
    CMatrix33 Inverse();
};

///
struct CMatrix44
{
    union
    {
        struct
        {
            float array[16];
        };
        struct
        {
            float _11, _12, _13, _14,
                  _21, _22, _23, _24,
                  _31, _32, _33, _34,
                  _41, _42, _43, _44;
        };
    };
    CMatrix44();
    CMatrix44(float m11, float m12, float m13, float m14,
              float m21, float m22, float m23, float m24,
              float m31, float m32, float m33, float m34,
              float m41, float m42, float m43, float m44);
    void IdenCMatrix();
    void ZeroCMatrix();
    CMatrix44 operator +(const CMatrix44 &mat) const;
    CMatrix44 operator -(const CMatrix44 &mat) const;
    CMatrix44 operator *(const CMatrix44 &mat) const;
    CVector3 operator *(const CVector3 &vet) const;
    CMatrix44 Tran();
    float Det();
    CMatrix44 Inverse();
};

const CMatrix44 cZeroCMatrix( 0.0f, 0.0f, 0.0f, 0.0f,
                             0.0f, 0.0f, 0.0f, 0.0f,
                             0.0f, 0.0f, 0.0f, 0.0f,
                             0.0f, 0.0f, 0.0f, 0.0f);

const CMatrix44 cIdenCCMatrix(1.0f, 0.0f, 0.0f, 0.0f,
                             0.0f, 1.0f, 0.0f, 0.0f,
                             0.0f, 0.0f, 1.0f, 0.0f,
                             0.0f, 0.0f, 0.0f, 1.0f);

#endif
