#include "Matrix.h"

CMatrix22::CMatrix22()
{
    IdenCMatrix();
}

CMatrix22::CMatrix22(float m11, float m12,
                     float m21, float m22)
{
    _11 = m11;  _12 = m12;
    _21 = m21;  _22 = m22;
}

void CMatrix22::IdentMatrix()
{
    _11 = 1.0f;  _12 = 0.0f;
    _21 = 0.0f;  _22 = 1.0f;
}

void CMatrix22::ZeroMatrix()
{
    _11 = 0.0f;  _12 = 0.0f;
    _21 = 0.0f;  _22 = 0.0f;
}


CMatrix22 CMatrix22::operator +(const CMatrix22 &mat) const
{
    CMatrix22 result;
    result._11=_11+mat._11;  result._12=_12+mat._12;
    result._21=_21+mat._21;  result._22=_22+mat._22;

    return result;
}

CMatrix22 CMatrix22::operator -(const CMatrix22 &mat) const
{
    CMatrix22 result;
    result._11=_11-mat._11;  result._12=_12-mat._12;
    result._21=_21-mat._21;  result._22=_22-mat._22;

    return result;
}

CMatrix22 CMatrix22::operator *(const CMatrix22 &mat) const
{
    CMatrix22 result;
    result._11 = (_11*mat._11)+(_12*mat._21);  result._12 = (_11*mat._12)+(_12*mat._22);
    result._21 = (_21*mat._11)+(_22*mat._21);  result._22 = (_21*mat._12)+(_22*mat._22);

    return result;
}

CMatrix22 CMatrix22::Tran()
{
    CMatrix22 result;
    result._11 = _11;  result._12 = _21;
    result._21 = _12;  result._22 = _22;

    return result;
}

float CMatrix22::Det()
{
    return (_11*_22)-(_12*_21);
}

CMatrix22 CMatrix22::Inverse()
{
    CMatrix22 result;
    float tdet = Det();

    if (tdet == 0) tdet = 0.1;
    result._11 = _22/tdet;  result._12 = -_12/tdet;
    result._21 = -_21/tdet;  result._22 = _11/tdet;

    return result;
}

CMatrix33::CMatrix33()
{
    IdenCMatrix();
}

CMatrix33::CMatrix33(float m11, float m12, float m13,
                     float m21, float m22, float m23,
                     float m31, float m32, float m33)
{
    _11 = m11;  _12 = m12;  _13 = m13;
    _21 = m21;  _22 = m22;  _23 = m23;
    _31 = m31;  _32 = m32;  _33 = m33;
}

void CMatrix33::IdenCMatrix()
{
    _11 = 1.0f;  _12 = 0.0f;  _13 = 0.0f;
    _21 = 0.0f;  _22 = 1.0f;  _23 = 0.0f;
    _31 = 0.0f;  _32 = 0.0f;  _33 = 1.0f;
}

void CMatrix33::ZeroMatrix()
{
    _11 = 0.0f;  _12 = 0.0f;  _13 = 0.0f;
    _21 = 0.0f;  _22 = 0.0f;  _23 = 0.0f;
    _31 = 0.0f;  _32 = 0.0f;  _33 = 0.0f;
}

CMatrix33 CMatrix33::operator +(const CMatrix33 &mat) const
{
    CMatrix33 result;

    result._11=_11+mat._11;  result._12=_12+mat._12;   result._13=_13+mat._13;
    result._21=_21+mat._21;  result._22=_22+mat._22;   result._23=_23+mat._23;
    result._31=_31+mat._31;  result._32=_32+mat._32;   result._33=_33+mat._33;

    return result;
}

CMatrix33 CMatrix33::operator -(const CMatrix33 &mat) const
{
    CMatrix33 result;

    result._11=_11-mat._11;  result._12=_12-mat._12;   result._13=_13-mat._13;
    result._21=_21-mat._21;  result._22=_22-mat._22;   result._23=_23-mat._23;
    result._31=_31-mat._31;  result._32=_32-mat._32;   result._33=_33-mat._33;

    return result;
}

CMatrix33 CMatrix33::operator *(const CMatrix33 &mat) const
{
    CMatrix33 result;

    result._11 = (_11*mat._11)+(_12*mat._21)+(_13*mat._31);
    result._12 = (_11*mat._12)+(_12*mat._22)+(_13*mat._32);
    result._13 = (_11*mat._13)+(_12*mat._23)+(_13*mat._33);

    result._21 = (_21*mat._11)+(_22*mat._21)+(_23*mat._31);
    result._22 = (_21*mat._12)+(_22*mat._22)+(_23*mat._32);
    result._23 = (_21*mat._13)+(_22*mat._23)+(_23*mat._33);

    result._31 = (_31*mat._11)+(_32*mat._21)+(_33*mat._31);
    result._32 = (_31*mat._12)+(_32*mat._22)+(_33*mat._32);
    result._33 = (_31*mat._13)+(_32*mat._23)+(_33*mat._33);

    return result;
}

TVector3 CMatrix33::operator *(const TVector3 &vet) const
{
    return TVector3( (_11*vet.vx)+(_12*vet.vy)+(_13*vet.vz),
                     (_21*vet.vx)+(_22*vet.vy)+(_23*vet.vz),
                     (_31*vet.vx)+(_32*vet.vy)+(_33*vet.vz) );
}

CMatrix33 CMatrix33::Tran()
{
    /* ���� ���� �ٲ�
    11 12 13       11 21 31
    21 22 23  -->  12 22 23
    31 32 33       13 23 33
    */
    CMatrix33 result;

    result._11=_11;  result._12=_21; result._13=_31;
    result._21=_12;  result._22=_22; result._23=_23;
    result._31=_13;  result._32=_23; result._33=_33;

    return result;
}

float CMatrix33::Det()
{
    CMatrix22 mat22;
    float dets[3];

    mat22._11 = _22;  mat22._12 = _23;
    mat22._21 = _32;  mat22._22 = _33;
    dets[0] = mat22.Det() * _11;

    mat22._11 = _21;  mat22._12 = _23;
    mat22._21 = _31;  mat22._22 = _33;
    dets[1] = mat22.Det() * _12;

    mat22._11 = _21;  mat22._12 = _22;
    mat22._21 = _31;  mat22._22 = _32;
    dets[2] = mat22.Det() * _13;

    return dets[0] - dets[1] + dets[2];
}

CMatrix33 CMatrix33::Inverse()
{
    /*
    a22a33 - a23a32    a13a32 - a12a33    a12a23 - a13a22
    a23a31 - a21a33    a11a33 - a13a31    a13a21 - a11a23
    a21a32 - a22a31    a12a31 - a11a32    a11a22 - a12a21
    */
    CMatrix33 result;
    float tdet = Det();

    if (tdet == 0) tdet = 0.1;
    result._11 = (_22*_33-_23*_32)*tdet;
    result._12 = (_13*_32-_12*_33)*tdet;
    result._13 = (_12*_23-_13*_22)*tdet;

    result._21 = (_23*_31-_21*_33)*tdet;
    result._22 = (_11*_33-_13*_31)*tdet;
    result._23 = (_13*_21-_11*_23)*tdet;

    result._31 = (_21*_32-_22*_31)*tdet;
    result._32 = (_12*_31-_11*_32)*tdet;
    result._33 = (_11*_22-_12*_21)*tdet;

    return result;
}


CMatrix44::CMatrix44()
{
    IdenCMatrix();
}

CMatrix44::CMatrix44(float m11, float m12, float m13, float m14,
                     float m21, float m22, float m23, float m24,
                     float m31, float m32, float m33, float m34,
                     float m41, float m42, float m43, float m44)
{
    _11 = m11;  _12 = m12;  _13 = m13;  _14 = m14;
    _21 = m21;  _22 = m22;  _23 = m23;  _24 = m24;
    _31 = m31;  _32 = m32;  _33 = m33;  _34 = m34;
    _41 = m41;  _42 = m42;  _43 = m43;  _44 = m44;
}

void CMatrix44::IdenCMatrix()
{
    _11 = 1.0f;  _12 = 0.0f;  _13 = 0.0f;  _14 = 0.0f;
    _21 = 0.0f;  _22 = 1.0f;  _23 = 0.0f;  _24 = 0.0f;
    _31 = 0.0f;  _32 = 0.0f;  _33 = 1.0f;  _34 = 0.0f;
    _41 = 0.0f;  _42 = 0.0f;  _43 = 0.0f;  _44 = 1.0f;
}

void CMatrix44::ZeroMatrix()
{
    _11 = 0.0f;  _12 = 0.0f;  _13 = 0.0f;  _14 = 0.0f;
    _21 = 0.0f;  _22 = 0.0f;  _23 = 0.0f;  _24 = 0.0f;
    _31 = 0.0f;  _32 = 0.0f;  _33 = 0.0f;  _34 = 0.0f;
    _41 = 0.0f;  _42 = 0.0f;  _43 = 0.0f;  _44 = 0.0f;
}

CMatrix44 CMatrix44::operator +(const CMatrix44 &mat) const
{
    CMatrix44 result;

    result._11=_11+mat._11;  result._12=_12+mat._12;  result._13=_13+mat._13;  result._14=_14+mat._14;
    result._21=_21+mat._21;  result._22=_22+mat._22;  result._23=_23+mat._23;  result._24=_24+mat._24;
    result._31=_31+mat._31;  result._32=_32+mat._32;  result._33=_33+mat._33;  result._34=_34+mat._34;
    result._41=_31+mat._41;  result._42=_42+mat._42;  result._43=_43+mat._43;  result._44=_44+mat._44;

    return result;
}

CMatrix44 CMatrix44::operator -(const CMatrix44 &mat) const
{
    CMatrix44 result;

    result._11=_11-mat._11;  result._12=_12-mat._12;  result._13=_13-mat._13;  result._14=_14-mat._14;
    result._21=_21-mat._21;  result._22=_22-mat._22;  result._23=_23-mat._23;  result._24=_24-mat._24;
    result._31=_31-mat._31;  result._32=_32-mat._32;  result._33=_33-mat._33;  result._34=_34-mat._34;
    result._41=_31-mat._41;  result._42=_42-mat._42;  result._43=_43-mat._43;  result._44=_44-mat._44;

    return result;
}

CMatrix44 CMatrix44::operator *(const CMatrix44 &mat) const
{
    CMatrix44 result;

    result._11 = (_11*mat._11)+(_12*mat._21)+(_13*mat._31)+(_14*mat._41);
    result._12 = (_11*mat._12)+(_12*mat._22)+(_13*mat._32)+(_14*mat._42);
    result._13 = (_11*mat._13)+(_12*mat._23)+(_13*mat._33)+(_14*mat._43);
    result._14 = (_11*mat._14)+(_12*mat._24)+(_13*mat._34)+(_14*mat._44);

    result._21 = (_21*mat._11)+(_22*mat._21)+(_23*mat._31)+(_24*mat._41);
    result._22 = (_21*mat._12)+(_22*mat._22)+(_23*mat._32)+(_24*mat._42);
    result._23 = (_21*mat._13)+(_22*mat._23)+(_23*mat._33)+(_24*mat._43);
    result._24 = (_21*mat._14)+(_22*mat._24)+(_23*mat._34)+(_24*mat._44);

    result._31 = (_31*mat._11)+(_32*mat._21)+(_33*mat._31)+(_34*mat._41);
    result._32 = (_31*mat._12)+(_32*mat._22)+(_33*mat._32)+(_34*mat._42);
    result._33 = (_31*mat._13)+(_32*mat._23)+(_33*mat._33)+(_34*mat._43);
    result._34 = (_31*mat._14)+(_32*mat._24)+(_33*mat._34)+(_34*mat._44);

    result._41 = (_41*mat._11)+(_42*mat._21)+(_43*mat._31)+(_44*mat._41);
    result._42 = (_41*mat._12)+(_42*mat._22)+(_43*mat._32)+(_44*mat._42);
    result._43 = (_41*mat._13)+(_42*mat._23)+(_43*mat._33)+(_44*mat._43);
    result._44 = (_41*mat._14)+(_42*mat._24)+(_43*mat._34)+(_44*mat._44);

    return result;
}

TVector3 CMatrix44::operator *(const TVector3 &vet) const
{
    return TVector3( (_11*vet.vx)+(_12*vet.vy)+(_13*vet.vz)+_14,
                     (_21*vet.vx)+(_22*vet.vy)+(_23*vet.vz)+_24,
                     (_31*vet.vx)+(_32*vet.vy)+(_33*vet.vz)+_34 );
}

CMatrix44 CMatrix44::Tran()
{
    CMatrix44 result;

    result._11=_11;  result._12=_21;  result._13=_31;  result._14=_41;
    result._21=_12;  result._22=_22;  result._23=_23;  result._24=_43;
    result._31=_13;  result._32=_23;  result._33=_33;  result._34=_43;
    result._31=_13;  result._32=_23;  result._33=_33;  result._44=_44;

    return result;
}


float CMatrix44::Det()
{
    return 0.0f;
}

CMatrix44 CMatrix44::Inverse()
{
    float tmp[12];
    CMatrix44 src, dst;
    float det;

    for ( int i = 0; i < 4; i++)
    {
        src.array[i] = array[i*4];
        src.array[i + 4] = array[i*4 + 1];
        src.array[i + 8] = array[i*4 + 2];
        src.array[i + 12] = array[i*4 + 3];
    }

    /* calculate pairs for first 8 elements (cofactors) */
    tmp[0]  = src.array[10] * src.array[15];
    tmp[1]  = src.array[11] * src.array[14];
    tmp[2]  = src.array[9 ] * src.array[15];
    tmp[3]  = src.array[11] * src.array[13];
    tmp[4]  = src.array[9 ] * src.array[14];
    tmp[5]  = src.array[10] * src.array[13];
    tmp[6]  = src.array[8 ] * src.array[15];
    tmp[7]  = src.array[11] * src.array[12];
    tmp[8]  = src.array[8 ] * src.array[14];
    tmp[9]  = src.array[10] * src.array[12];
    tmp[10] = src.array[8 ] * src.array[13];
    tmp[11] = src.array[9 ] * src.array[12];

    /* calculate first 8 elements (cofactors) */
    dst.array[0]  = tmp[0]*src.array[5] + tmp[3]*src.array[6] + tmp[4 ]*src.array[7];
    dst.array[0] -= tmp[1]*src.array[5] + tmp[2]*src.array[6] + tmp[5 ]*src.array[7];
    dst.array[1]  = tmp[1]*src.array[4] + tmp[6]*src.array[6] + tmp[9 ]*src.array[7];
    dst.array[1] -= tmp[0]*src.array[4] + tmp[7]*src.array[6] + tmp[8 ]*src.array[7];
    dst.array[2]  = tmp[2]*src.array[4] + tmp[7]*src.array[5] + tmp[10]*src.array[7];
    dst.array[2] -= tmp[3]*src.array[4] + tmp[6]*src.array[5] + tmp[11]*src.array[7];
    dst.array[3]  = tmp[5]*src.array[4] + tmp[8]*src.array[5] + tmp[11]*src.array[6];
    dst.array[3] -= tmp[4]*src.array[4] + tmp[9]*src.array[5] + tmp[10]*src.array[6];
    dst.array[4]  = tmp[1]*src.array[1] + tmp[2]*src.array[2] + tmp[5 ]*src.array[3];
    dst.array[4] -= tmp[0]*src.array[1] + tmp[3]*src.array[2] + tmp[4 ]*src.array[3];
    dst.array[5]  = tmp[0]*src.array[0] + tmp[7]*src.array[2] + tmp[8 ]*src.array[3];
    dst.array[5] -= tmp[1]*src.array[0] + tmp[6]*src.array[2] + tmp[9 ]*src.array[3];
    dst.array[6]  = tmp[3]*src.array[0] + tmp[6]*src.array[1] + tmp[11]*src.array[3];
    dst.array[6] -= tmp[2]*src.array[0] + tmp[7]*src.array[1] + tmp[10]*src.array[3];
    dst.array[7]  = tmp[4]*src.array[0] + tmp[9]*src.array[1] + tmp[10]*src.array[2];
    dst.array[7] -= tmp[5]*src.array[0] + tmp[8]*src.array[1] + tmp[11]*src.array[2];

    /* calculate pairs for second 8 elements (cofactors) */
    tmp[0]  = src.array[2]*src.array[7];
    tmp[1]  = src.array[3]*src.array[6];
    tmp[2]  = src.array[1]*src.array[7];
    tmp[3]  = src.array[3]*src.array[5];
    tmp[4]  = src.array[1]*src.array[6];
    tmp[5]  = src.array[2]*src.array[5];
    tmp[6]  = src.array[0]*src.array[7];
    tmp[7]  = src.array[3]*src.array[4];
    tmp[8]  = src.array[0]*src.array[6];
    tmp[9]  = src.array[2]*src.array[4];
    tmp[10] = src.array[0]*src.array[5];
    tmp[11] = src.array[1]*src.array[4];

    /* calculate second 8 elements (cofactors) */
    dst.array[8]  = tmp[ 0]*src.array[13] + tmp[ 3]*src.array[14] + tmp[ 4]*src.array[15];
    dst.array[8] -= tmp[ 1]*src.array[13] + tmp[ 2]*src.array[14] + tmp[ 5]*src.array[15];
    dst.array[9]  = tmp[ 1]*src.array[12] + tmp[ 6]*src.array[14] + tmp[ 9]*src.array[15];
    dst.array[9] -= tmp[ 0]*src.array[12] + tmp[ 7]*src.array[14] + tmp[ 8]*src.array[15];
    dst.array[10] = tmp[ 2]*src.array[12] + tmp[ 7]*src.array[13] + tmp[10]*src.array[15];
    dst.array[10]-= tmp[ 3]*src.array[12] + tmp[ 6]*src.array[13] + tmp[11]*src.array[15];
    dst.array[11] = tmp[ 5]*src.array[12] + tmp[ 8]*src.array[13] + tmp[11]*src.array[14];
    dst.array[11]-= tmp[ 4]*src.array[12] + tmp[ 9]*src.array[13] + tmp[10]*src.array[14];
    dst.array[12] = tmp[ 2]*src.array[10] + tmp[ 5]*src.array[11] + tmp[ 1]*src.array[ 9];
    dst.array[12]-= tmp[ 4]*src.array[11] + tmp[ 0]*src.array[ 9] + tmp[ 3]*src.array[10];
    dst.array[13] = tmp[ 8]*src.array[11] + tmp[ 0]*src.array[ 8] + tmp[ 7]*src.array[10];
    dst.array[13]-= tmp[ 6]*src.array[10] + tmp[ 9]*src.array[11] + tmp[ 1]*src.array[ 8];
    dst.array[14] = tmp[ 6]*src.array[ 9] + tmp[11]*src.array[11] + tmp[ 3]*src.array[ 8];
    dst.array[14]-= tmp[10]*src.array[11] + tmp[ 2]*src.array[ 8] + tmp[ 7]*src.array[ 9];
    dst.array[15] = tmp[10]*src.array[10] + tmp[ 4]*src.array[ 8] + tmp[ 9]*src.array[ 9];
    dst.array[15]-= tmp[ 8]*src.array[ 9] + tmp[11]*src.array[10] + tmp[ 5]*src.array[ 8];

    /* calculate determinant */
    det = src.array[0]*dst.array[0]+src.array[1]*dst.array[1]+src.array[2]*dst.array[2]+src.array[3]*dst.array[3];

    /* calculate matrix inverse */
    det = 1/det;
    for ( int j = 0; j < 16; j++)
        dst.array[j] *= det;

    return dst;
}
