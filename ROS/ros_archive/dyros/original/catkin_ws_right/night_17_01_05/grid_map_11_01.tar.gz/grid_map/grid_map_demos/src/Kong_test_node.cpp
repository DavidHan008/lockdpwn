
#include <ros/ros.h>
#include "grid_map_demos/Kong_test.hpp"
#include <grid_map_ros/grid_map_ros.hpp>
#include <grid_map_msgs/GridMap.h>
#include <cmath>

using namespace grid_map;
int main(int argc, char** argv)
{
  // Initialize node and publisher.
  ros::init(argc, argv, "Kong_test");
 // ros::NodeHandle nodeHandle("~");  //topic : grid_map_simple_demo/grid_map
  ros::NodeHandle nodeHandle;     //topic : grid_map
  grid_map_demos::KongTest hm(nodeHandle);

  ros::spin();
  return 0;
}
