#include <ros/ros.h>

#include "grid_map_demos/vectorfield.hpp"

#include <pcl_ros/point_cloud.h>
#include <grid_map_ros/grid_map_ros.hpp>
#include <vector>
#include <string>
#include <cmath>
#include <limits>
#include <grid_map_msgs/GridMap.h>
#include <iostream>

using namespace grid_map;
namespace grid_map_demos
{
VField::VField(ros::NodeHandle nodeHandle)
    : nodeHandle(nodeHandle),
      map(grid_map::GridMap({"elevation", "normal_x", "normal_y", "normal_z"})),
      mapInitialized(false)
{

data_sub_ = nodeHandle.subscribe("free", 1, &VField::DataCallback,
                               this, ros::TransportHints().tcpNoDelay(true));

gridMapPublisher = nodeHandle.advertise<grid_map_msgs::GridMap>("grid_map", 1, true);
}

VField::~VField()
{
}

void VField::DataCallback(const VPointCloud::ConstPtr &scan)

{
    if(!mapInitialized)
    {
    map.setFrameId("map");
    map.setGeometry(Length(1.2, 2.0), 0.03);
    ROS_INFO("Created map with size %f x %f m (%i x %i cells)",
      map.getLength().x(), map.getLength().y(),
      map.getSize()(0), map.getSize()(1));
mapInitialized=true;
    }

    ros::Time time = ros::Time::now();

    for (GridMapIterator it(map); !it.isPastEnd(); ++it) {
      Position position;
      map.getPosition(*it, position);
      map.at("elevation", *it) = -0.04 + 0.2 * std::sin(3.0 * time.toSec() + 5.0 * position.y()) * position.x();
      Eigen::Vector3d normal(-0.2 * std::sin(3.0 * time.toSec() + 5.0 * position.y()),
                             -position.x() * std::cos(3.0 * time.toSec() + 5.0 * position.y()), 1.0);
      normal.normalize();
      map.at("normal_x", *it) = normal.x();
      map.at("normal_y", *it) = normal.y();
      map.at("normal_z", *it) = normal.z();

      // Add elevation and surface normal (iterating through grid map and adding data).

    }


    // Publish grid map.
    map.setTimestamp(time.toNSec());
    grid_map_msgs::GridMap message;
    GridMapRosConverter::toMessage(map, message);
    gridMapPublisher.publish(message);

}

}
