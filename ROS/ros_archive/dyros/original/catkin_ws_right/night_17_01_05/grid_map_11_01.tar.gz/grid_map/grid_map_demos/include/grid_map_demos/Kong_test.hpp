/*
 * ImageToGridmapDemo.hpp
 *
 *  Created on: May 4, 2015
 *      Author: Martin Wermelinger
 *	 Institute: ETH Zurich, Autonomous Systems Lab
 *
 */

#pragma once

// ROS
#include <ros/ros.h>
#include <sensor_msgs/Image.h>
#include <stdlib.h>
#include <grid_map_msgs/GridMap.h>
#include <grid_map_ros/grid_map_ros.hpp>
#include <pcl_ros/point_cloud.h>
#include <nav_msgs/Path.h>
#include <sensor_msgs/LaserScan.h>
#include <cmath>
#include <string>

namespace grid_map_demos {

typedef pcl::PointXYZI VPoint;
typedef pcl::PointCloud<VPoint> VPointCloud;

/*!
 * Loads an image and saves it as layer 'elevation' of a grid map.
 * The grid map is published and can be viewed in Rviz.
 */
class KongTest
{
 public:

  /*!
   * Constructor.
   * @param nodeHandle the ROS node handle.
   */
  KongTest(ros::NodeHandle nodeHandle);

  /*!
   * Destructor.
   */
  virtual ~KongTest();

  /*!
  * Reads and verifies the ROS parameters.
  * @return true if successful.
  */
  bool readParameters();

//  void imageCallback(const sensor_msgs::Image& msg);
  void FCallback(const VPointCloud::ConstPtr &scan);
  void VCallback(const VPointCloud::ConstPtr &scan);
  void OCallback(const VPointCloud::ConstPtr &scan);

  void LCallback(const sensor_msgs::LaserScan::ConstPtr &scan);
  void LPCallback(const sensor_msgs::LaserScan::ConstPtr &scan);
  void MCallback(const nav_msgs::Path::ConstPtr& msg);
  void CCallback(const std_msgs::Float32MultiArray::ConstPtr &scan);

  float car_now_x;
  float car_now_y;
  float car_now_angle;
  float minimumx;
  float maximumy;
//Linking
 private:

  //! ROS nodehandle.
  ros::NodeHandle nodeHandle_;

  //! Grid map publisher.
  ros::Publisher gridMapPublisher_;

  //! Grid map data.
  grid_map::GridMap map_;

  //! Image subscriber
  //ros::Subscriber imageSubscriber_;
  ros::Subscriber free_sub_;
  ros::Subscriber occu_sub_;
  ros::Subscriber velo_sub_;

  ros::Subscriber laserup_sub_;
  ros::Subscriber laser_sub_;
  ros::Subscriber global_sub_;
  ros::Subscriber car_sub_;
  //! Length of the grid map in x direction.
  double mapLengthX_;

  //! Resolution of the grid map.
  double resolution_;

  //! Range of the height values.
  double minHeight_;
  double maxHeight_;

  //! Frame id of the grid map.
  std::string mapFrameId_;

  bool mapInitialized_;

////
  // Point clouds generated in processData
  VPointCloud free_;
  VPointCloud vel_;
  VPointCloud obs_;
  VPointCloud occu_;
  sensor_msgs::LaserScan laser_;
  sensor_msgs::LaserScan laser_up_;
  std_msgs::Float32MultiArray car_;
  nav_msgs::Path global_;


  void constructGridClouds(const VPointCloud::ConstPtr &scan, unsigned npoints,
                           size_t &obs_count, size_t &empty_count);
  void constructFullClouds(const VPointCloud::ConstPtr &scan, unsigned npoints,
                           size_t &obs_count, size_t &empty_count);


};

} /* namespace */
