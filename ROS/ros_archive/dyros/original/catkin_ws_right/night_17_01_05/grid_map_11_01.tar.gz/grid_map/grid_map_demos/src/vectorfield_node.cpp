#include <ros/ros.h>
#include <grid_map_ros/grid_map_ros.hpp>
#include <vector>
#include <string>
#include <cmath>
#include <limits>
#include <grid_map_msgs/GridMap.h>
#include "grid_map_demos/vectorfield.hpp"


using namespace grid_map;

int main(int argc, char** argv)
{
  // Initialize node and publisher.
  ros::init(argc, argv, "vectorfield");
  ros::NodeHandle nodeHandle;
  grid_map_demos::VField hm(nodeHandle);
  ros::spin();
  return 0;
}
