^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package grid_map_rviz_plugin
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Forthcoming
-----------
* Added functionality to invert rainbow colors in RViz plugin.
* Contributors: Philipp Kruesi

1.4.0 (2016-08-22)
------------------
* Added new package grid_map_rviz_plugin to visualize grid map layers as 3d surfaces.
* Updated documentation.
* Contributors: Péter Fankhauser, Philipp Kruesi
