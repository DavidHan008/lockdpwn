/*
 * ImageToGridmapDemo.hpp
 *
 *  Created on: May 4, 2015
 *      Author: Martin Wermelinger
 *	 Institute: ETH Zurich, Autonomous Systems Lab
 *
 */

#pragma once

// ROS
#include <ros/ros.h>
#include <sensor_msgs/Image.h>
#include <stdlib.h>
#include <grid_map_msgs/GridMap.h>
#include <grid_map_ros/grid_map_ros.hpp>
#include <pcl_ros/point_cloud.h>
#include <nav_msgs/Path.h>
#include <sensor_msgs/LaserScan.h>
#include <cmath>
#include <string>

namespace grid_map_demos {

typedef pcl::PointXYZI VPoint;
typedef pcl::PointCloud<VPoint> VPointCloud;

class VField
{
 public:

  /*!
   * Constructor.
   * @param nodeHandle the ROS node handle.
   */
  VField(ros::NodeHandle nodeHandle);

  /*!
   * Destructor.
   */
  virtual ~VField();

  /*!
  * Reads and verifies the ROS parameters.
  * @return true if successful.
  */
  bool readParameters();

//  void imageCallback(const sensor_msgs::Image& msg);
  void DataCallback(const VPointCloud::ConstPtr &scan);


 private:

  //! ROS nodehandle.
  ros::NodeHandle nodeHandle;

  //! Grid map publisher.
  ros::Publisher gridMapPublisher;

  //! Grid map data.
  grid_map::GridMap map;

  ros::Subscriber data_sub_;

  //! Image subscriber
//  ros::Subscriber free_sub_;
  //! Frame id of the grid map.
  std::string mapFrameId;

  bool mapInitialized;

////
  // Point clouds generated in processData
  VPointCloud data_;
 /* VPointCloud vel_;
  VPointCloud obs_;
  VPointCloud occu_;
  sensor_msgs::LaserScan laser_;
  sensor_msgs::LaserScan laser_up_;
  std_msgs::Float32MultiArray car_;
  nav_msgs::Path global_;
*/


  void constructGridClouds(const VPointCloud::ConstPtr &scan, unsigned npoints,
                           size_t &obs_count, size_t &empty_count);
  void constructFullClouds(const VPointCloud::ConstPtr &scan, unsigned npoints,
                           size_t &obs_count, size_t &empty_count);


};

} /* namespace */
