^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package grid_map
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Forthcoming
-----------

1.4.0 (2016-08-22)
------------------
* Added new package grid_map_rviz_plugin.
* Contributors: Peter Fankhauser

1.3.3 (2016-05-10)
------------------
* Release for ROS Kinetic.
* Contributors: Peter Fankhauser

1.3.2 (2016-05-10)
------------------

1.3.1 (2016-05-10)
------------------

1.3.0 (2016-04-26)
------------------
* Separated OpenCV to grid map conversions to grid_map_cv package. The new methods
  are more generalized, faster, and can be used without ROS message types.
* Contributors: Peter Fankhauser

1.2.0 (2016-03-03)
------------------
* Added new package grid_map as metapackage (`#34 <https://github.com/ethz-asl/grid_map/issues/34>`_).
