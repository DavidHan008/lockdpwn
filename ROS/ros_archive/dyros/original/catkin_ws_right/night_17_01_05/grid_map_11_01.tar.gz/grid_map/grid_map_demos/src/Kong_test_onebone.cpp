#include <ros/ros.h>
#include <grid_map_ros/grid_map_ros.hpp>
#include <grid_map_msgs/GridMap.h>

#include <cmath>
#include <iostream>
#include "grid_map_demos/Kong_test.hpp"

using namespace grid_map;
namespace grid_map_demos {

KongTest::KongTest(ros::NodeHandle nodeHandle)
    : nodeHandle_(nodeHandle),
      map_(grid_map::GridMap({"elevation", "elevation_free", "elevation_laser", "elevation_uplaser", "elevation_vector", "normal_x", "normal_y", "normal_z"})),
      mapInitialized_(false)
{
ROS_INFO("make");
  map_.setFrameId("map");
  global_sub_ = nodeHandle_.subscribe("LocalPathData", 10, &KongTest::MCallback,
                    this, ros::TransportHints().tcpNoDelay(true));

  car_sub_ = nodeHandle_.subscribe("LocalizationData", 1, &KongTest::CCallback,
                    this, ros::TransportHints().tcpNoDelay(true));

  velo_sub_ = nodeHandle_.subscribe("velodyne_points", 1, &KongTest::VCallback,
					this, ros::TransportHints().tcpNoDelay(true));

  free_sub_ = nodeHandle_.subscribe("free", 1, &KongTest::FCallback, 
					this, ros::TransportHints().tcpNoDelay(true));

  laserup_sub_ = nodeHandle_.subscribe("scan_upper", 1, &KongTest::LPCallback,
                    this, ros::TransportHints().tcpNoDelay(true));

  laser_sub_ = nodeHandle_.subscribe("scan_front", 1, &KongTest::LCallback,
					this, ros::TransportHints().tcpNoDelay(true));

  occu_sub_ = nodeHandle_.subscribe("occupancy", 1, &KongTest::OCallback, 
					this, ros::TransportHints().tcpNoDelay(true));
//  map_.add("elevation_free", map_.get("elevation_free")+map_.get("elevation_laser"));

  gridMapPublisher_ = nodeHandle_.advertise<grid_map_msgs::GridMap>("grid_map", 1, true);
}

KongTest::~KongTest()
{
}

//Global Map call back
void KongTest::MCallback(const nav_msgs::Path::ConstPtr& msg)
{
//   ROS_INFO("Global_Map_callback run!");


    float resol=0.5;
    float maximumx=-200, minimumx=200;
    float maximumy=-200, minimumy=200;

//std::cout<<msg->poses.size();
    for(int i=0; i<msg->poses.size(); i++)
    { if(minimumy>msg->poses[i].pose.position.y)
       minimumy=msg->poses[i].pose.position.y;
      if(maximumy<msg->poses[i].pose.position.y)
       maximumy=msg->poses[i].pose.position.y;

      if(minimumx>msg->poses[i].pose.position.x)
     minimumx=msg->poses[i].pose.position.x;
    if(maximumx<msg->poses[i].pose.position.x)
     maximumx=msg->poses[i].pose.position.x;
    }

//    std::cout<<"(minimum x , minimum y) = "<<"("<<minimumx<<" , "<<minimumy<<")";
//    std::cout<<"(maximum x , maximum y) = "<<"("<<maximumx<<" , "<<maximumy<<")";
//min(x,y)=(-0.115511, -24.664)
//max(x,y)=(30.8947, 70.8584)


//    int MapYLength=maximumy-minimumy+10;
//    int MapXLength=maximumx-minimumx+10;   //+10, +10 height, length

    int MapYLength=floor(maximumy-minimumy)+20; //95 Lx=(95.5224)
    int MapXLength=floor(maximumx-minimumx)+20; //31 Ly=(30.9089511)      //compact

//    std::cout<<"max : "<< MapXLength<<std::endl;
//    std::cout<<"min : "<< MapYLength<<std::endl;


    global_.header.stamp = msg->header.stamp;
      global_.header.frame_id = msg->header.frame_id;

      map_.setGeometry(grid_map::Length(MapYLength, MapXLength), 0.5);
   ROS_INFO("Initialized map with size %f x %f m (%i x %i cells).", map_.getLength().x(),
             map_.getLength().y(), map_.getSize()(0), map_.getSize()(1));

   int NumofCell=MapYLength*MapXLength/(resol*resol);
   float MapX[NumofCell], MapY[NumofCell];
   float It_Map[NumofCell];
   int IndexNum=0;
   int MiniI=99999, MaxiI=0;

   for (int i=0; i<NumofCell; i++)
   {
       It_Map[i]=4;
   }


   //here!!
   for (unsigned i = 0; i < msg->poses.size(); ++i)
   {//(MapX,MapY)=(n,m)

//   MapY[i]=floor((((-1)*msg->poses[i].pose.position.y+maximumy)/0.5)+5); //(n)
   MapY[i]=floor((((-1)*msg->poses[i].pose.position.y+maximumy)/0.5)+20); //(n)
   MapX[i]=floor(((msg->poses[i].pose.position.x-minimumx)/0.5)+20); //(m)


   // MapY[i]=floor((((-1)*msg->poses[i].pose.position.y+maximumy)/0.5)+5); //(n)

   // MapX[i]=floor(((msg->poses[i].pose.position.x-minimumx)/0.5)+5); //(m)
   //MapX[i]=floor((msg->poses[i].pose.position.x-maximumx)/resol); //(m)

IndexNum=(MapY[i]+1)+MapYLength*2*(MapX[i]);
It_Map[IndexNum] = 3;

for (int k=1; k<10; k++)
{
    It_Map[IndexNum+k] = 3;
It_Map[IndexNum-k] = 3;
It_Map[IndexNum+MapYLength*2*k] = 3;
It_Map[IndexNum-MapYLength*2*k] = 3;
}


//   if(MiniI>IndexNum)
//    MiniI=IndexNum;
//   if(MaxiI<IndexNum)
//    MaxiI=IndexNum;
//std::cout<<MapY[i]<<std::endl;  //145
//std::cout<<MapX[i]<<std::endl;  //61

}

//std::cout<<MapYLength;

//std::cout<<"Max : "<<MaxiI<<std::endl;
//std::cout<<"Min : "<<MiniI<<std::endl;

 ros::Time time = ros::Time::now();
  unsigned i=0;
  for (grid_map::GridMapIterator it(map_); !it.isPastEnd(); ++it)
  {if(i!=NumofCell)
{ Position position;
map_.getPosition(*it, position);
   map_.at("elevation", *it) = It_Map[i];
   i++;
      }
      else
      {
          break;}

   }

   // Publish as grid map.
   map_.setTimestamp(time.toNSec());
   grid_map_msgs::GridMap message;
   grid_map::GridMapRosConverter::toMessage(map_, message);
 //toMessage(map name==map_, message name);
   gridMapPublisher_.publish(message);

}


void KongTest::CCallback(const std_msgs::Float32MultiArray::ConstPtr &scan)
{
 // ROS_INFO("CarData_callback run!");
//0.5 : offset
  car_now_y=((-1)*((-1)*(scan->data.at(1))+24.5));//-(-24.664)));//+95  //y
  car_now_x=(((-1)*(scan->data.at(0))+30.8947/2)-1);
  car_now_angle=(3.1415926536+1.57079631-(scan->data.at(2)));

  //    int MapYLength=floor(maximumy-minimumy)+20; //95 Lx=(95.5224)
  //    int MapXLength=floor(maximumx-minimumx)+20; //31 Ly=(30.9089511)      //compact

  //    std::cout<<"max : "<< MapXLength<<std::endl;
  //    std::cout<<"min : "<< MapYLength<<std::endl;

  // 1.57079631  //pi/2
  // 3.1415926536//pi
          ;//-(70.8584))); //+31   //x

//  std::cout<<"("<<car_now_y<<" , "<<car_now_x<<")"<<std::endl;
  //std::cout<<car_now_x;
  //min(x,y)=(-0.115511, -24.664)
//max(x,y)=(30.8947, 70.8584)


// MapY[i]=floor((((-1)*msg->poses[i].pose.position.y+maximumy)/0.5)+5); //(n)

// MapX[i]=floor(((msg->poses[i].pose.position.x-minimumx)/0.5)+5); //(m)

  if (!mapInitialized_) {

     map_.setGeometry(grid_map::Length(1, 1), 0.5);
     ROS_INFO("Initialized map with size %f x %f m (%i x %i cells).", map_.getLength().x(),
              map_.getLength().y(), map_.getSize()(0), map_.getSize()(1));
     mapInitialized_ = true;
   }

  //moving!!
     Position newPosition = Position(car_now_y,car_now_x);
     map_.setPosition(newPosition);
  // moving!!
     ros::Time time = ros::Time::now();

/*     float debug[15625];

     for (int i=0; i<15625; i++)
     {
         debug[i]=0;
     }
     debug[15625]=2;
     debug[15624]=2;
     debug[15623]=2;
     debug[15622]=2;
     debug[15500]=2;
     debug[0]=2;
     debug[15376-1]=2;
     debug[15252-2]=2;
     */
     unsigned i=0;
     for (grid_map::GridMapIterator it(map_); !it.isPastEnd(); ++it)
     {if(i!=4)
  { Position position;
   map_.getPosition(*it, position);
      map_.at("elevation_free", *it) = 10; // localization layer!!!
      i++;
         }
         else
         {
             break;}
     }

     // Publish as grid map.
     map_.setTimestamp(time.toNSec());
     grid_map_msgs::GridMap message;
     grid_map::GridMapRosConverter::toMessage(map_, message);
   //toMessage(map name==map_, message name);
     gridMapPublisher_.publish(message);

}

void KongTest::VCallback(const VPointCloud::ConstPtr &scan)
{
// ROS_INFO("velo_callback run!");
/*
 size_t npoints = scan->points.size();
 vel_.points.resize(npoints);
 //std::cout<<npoints;

 float Velo_resol=0.5;
 float Velo_maximumx=-99999, Velo_minimumx=99999;
 float Velo_maximumy=-99999, Velo_minimumy=99999;
 for(int i=0; i<npoints; i++)
 { if(Velo_minimumy>scan->points[i].y)
    Velo_minimumy=scan->points[i].y;
   if(Velo_maximumy<scan->points[i].y)
    Velo_maximumy=scan->points[i].y;

   if(Velo_minimumx>scan->points[i].x)
  Velo_minimumx=scan->points[i].x;
 if(Velo_maximumx<scan->points[i].x)
  Velo_maximumx=scan->points[i].x;
 }

 std::cout<<"(minimum x , minimum y) = "<<"("<<Velo_minimumx<<" , "<<Velo_minimumy<<")";
 std::cout<<"(maximum x , maximum y) = "<<"("<<Velo_maximumx<<" , "<<Velo_maximumy<<")";

//    int MapYLength=maximumy-minimumy+10;
//    int MapXLength=maximumx-minimumx+10;   //+10, +10 height, length

 int Velo_MapYLength=Velo_maximumy-Velo_minimumy; //garo
 int Velo_MapXLength=Velo_maximumx-Velo_minimumx; //sero




// int Velo_YCell=Velo_MapYLength/0.4;
// int Velo_XCell=Velo_MapXLength/0.4;

// int R=(Velo_YCell-125)/2;
// int C=(Velo_XCell-125)/2;

 //std::cout<<"Xlen : "<<Velo_MapXLength;
 //std::cout<<"Ylen : "<<Velo_MapYLength;

 if (!mapInitialized_) {
       vel_.header.stamp = scan->header.stamp;
       vel_.header.frame_id = scan->header.frame_id; //frame_id -> velodyne

      map_.setGeometry(grid_map::Length(Velo_MapYLength, Velo_Map_XLength), 0.1);
      ROS_INFO("Initialized map with size %f x %f m (%i x %i cells).", map_.getLength().x(),
               map_.getLength().y(), map_.getSize()(0), map_.getSize()(1));
      mapInitialized_ = true;
 }

   ros::Time time = ros::Time::now();
     float velo_z[15625];
     float velo_zx[npoints];
   for (unsigned i = 0; i < npoints; ++i) {
         velo_zx[i] = scan->points[i].z;}

   for (unsigned i = 0; i < 15625; ++i) {
         velo_z[i] = velo_zx[Velo_MapYLength*(R+i/125)+(C+i%125)];}

   //i error!!!


   unsigned i=0;
   for (grid_map::GridMapIterator it(map_); !it.isPastEnd(); ++it)
   {if(i!=npoints)
       { Position position;
map_.getPosition(*it, position);
//  map_.at("elevation", *it) = velo_zx[Velo_MapYLength*(R+i/125)+(C+i%125)]*2;
  map_.at("elevation", *it) = scan->points[i].z;

  i++;

     }
     else
     {
         break;}
}
  // Publish as grid map.
  map_.setTimestamp(time.toNSec());
  grid_map_msgs::GridMap message;
  grid_map::GridMapRosConverter::toMessage(map_, message); 
//toMessage(map name==map_, message name); 
  gridMapPublisher_.publish(message);
*/
}


//free
void KongTest::FCallback(const VPointCloud::ConstPtr &scan)
{
/*//  ROS_INFO("free_callback run!");
  if (!mapInitialized_) {
    free_.header.stamp = scan->header.stamp;
    free_.header.frame_id = scan->header.frame_id; //frame_id -> velodyne

     map_.setGeometry(grid_map::Length(72, 72), 0.4);  // 72*72 length, 0.4 resol, 180 * 180 cell
     ROS_INFO("Initialized map with size %f x %f m (%i x %i cells).", map_.getLength().x(),
              map_.getLength().y(), map_.getSize()(0), map_.getSize()(1));
     mapInitialized_ = true;
   }
  ros::Time time = ros::Time::now();

   float sugar_free_z[32400];
   float ffar[180][180];
   float wfar[180][180];

   for (int i = 0; i < 32400; i++)
     {
           sugar_free_z[i] = 0;
//           sugar_free_z[125*(124-(i%125))+125-(i/125)] = scan->points[i].z;


   }


float ang=car_now_angle;
     for (int i=0; i<125; i++)
     {
         for (int j=0; j<125; j++)
         {
ffar[i+27][j+27]=scan->points[i*125+j].z;
         }
     }


//27~151

for (int i=0; i<125; i++)
     {
         for (int j=0; j<125; j++)
         {
int k1=floor(cos(ang)*(i+27+1-90)-sin(ang)*(j+27+1-90)+90);
int k2=floor(sin(ang)*(i+27+1-90)+cos(ang)*(j+27+1-90)+90); // rotated i,j = k1, k2

    wfar[k1][k2]=ffar[j+27][i+27];

             sugar_free_z[(k1*180)+k2]=wfar[k1][k2];
    //             sugar_free_z[(j+27)*180+i+27]=wfar[k1][k2];
         }
     }
unsigned i=0;

Position newPosition = Position(car_now_y,car_now_x);
map_.setPosition(newPosition);


for (grid_map::GridMapIterator it(map_); !it.isPastEnd(); ++it)
{if(i!=32400)
{ Position position;
map_.getPosition(*it, position);
    map_.at("elevation_free", *it) = sugar_free_z[i];

 i++;

    }
    else
    {
        break;}
}
//   std::cout<<i<<std::endl;
   map_.setTimestamp(time.toNSec());
   grid_map_msgs::GridMap message;
   grid_map::GridMapRosConverter::toMessage(map_, message);
 //toMessage(map name==map_, message name);
   gridMapPublisher_.publish(message);
*/
}


void KongTest::LPCallback(const sensor_msgs::LaserScan::ConstPtr &scan)
{
    //    ROS_INFO("laser_upper_callback run!");
      if (!mapInitialized_) {
    //       map_.setGeometry(grid_map::Length(50, 50), 0.4);
          map_.setGeometry(grid_map::Length(72, 72), 0.4);
    //moving
           ROS_INFO("Initialized map with size %f x %f m (%i x %i cells).", map_.getLength().x(),
                  map_.getLength().y(), map_.getSize()(0), map_.getSize()(1));
         mapInitialized_ = true;


       }
      ros::Time time = ros::Time::now();

float resol1, resol2, resol3;
resol1=scan->angle_increment;
resol2=scan->angle_min;
resol3=scan->angle_max;
float resol4=(resol3-resol2)/resol1;

float luar[361];
float NumX[361], NumY[361];
float It_Ulidar[32400];
int INum=0;
float ang=car_now_angle;

for (unsigned i = 0; i < 361; ++i)  // 361 -> resol4 ((angle_max-angle_min)/increment)
{luar[i] = scan->ranges[i];}
         for (int i=0; i<32400; i++)
          {
              It_Ulidar[i]=-5;
          }

          for (unsigned i = 0; i < 361; ++i)  // 361 -> resol4 ((angle_max-angle_min)/increment)
          {luar[i] = scan->ranges[i];

          NumX[i]=floor((luar[i]*cos(resol2+resol1*i)))-3; //(n)
          NumY[i]=floor((luar[i]*sin(resol2+resol1*i))); //(m)
                  //+36/0.4; //(m)
          int k1=round(cos(-ang)*(NumX[i])-sin(-ang)*(NumY[i]))+36/0.4;
          int k2=round(sin(-ang)*(NumX[i])+cos(-ang)*(NumY[i]))+36/0.4;

          INum=(180-k1+1)+180*(180-k2);
              It_Ulidar[INum] = 5;
          }


         Position newPosition = Position(car_now_y,car_now_x);
         map_.setPosition(newPosition);
      // moving!!

         unsigned i=0;
         for (grid_map::GridMapIterator it(map_); !it.isPastEnd(); ++it)
         {if(i!=32400)
      { Position position;
       map_.getPosition(*it, position);
          map_.at("elevation_uplaser", *it) = It_Ulidar[i];
          i++;
             }

             else
             {
                 break;}
         }
         // Publish as grid map.
         map_.setTimestamp(time.toNSec());
         grid_map_msgs::GridMap message;
         grid_map::GridMapRosConverter::toMessage(map_, message);
       //toMessage(map name==map_, message name);
         gridMapPublisher_.publish(message);
      }

//Laser Call back!
void KongTest::LCallback(const sensor_msgs::LaserScan::ConstPtr &scan)
{
//    ROS_INFO("laser_callback run!");
  if (!mapInitialized_) {
//       map_.setGeometry(grid_map::Length(50, 50), 0.4);
      map_.setGeometry(grid_map::Length(72, 72), 0.4);
//moving
       ROS_INFO("Initialized map with size %f x %f m (%i x %i cells).", map_.getLength().x(),
              map_.getLength().y(), map_.getSize()(0), map_.getSize()(1));
     mapInitialized_ = true;
   }


  ros::Time time = ros::Time::now();

    float resol1, resol2, resol3;
    resol1=scan->angle_increment;
    resol2=scan->angle_min;
    resol3=scan->angle_max;
    float resol4=(resol3-resol2)/resol1;

//    std::cout<<"max degree : "<<resol3*(180/3.14)<<std::endl;
//    std::cout<<"min degree : "<<resol2*(180/3.14)<<std::endl;
//    std::cout<<"max-min degree : "<<(resol3-resol2)*(180/3.14)<<std::endl;
//    std::cout<<"incre degree : "<<resol1*((180/3.14))<<std::endl;
//    std::cout<<"size : "<<resol4<<std::endl;

    /* how many(npoints)= 360 */

    float llar[361];
    float NumX[361], NumY[361], NumuX[361], NumuY[361];
    float It_lidar[32400];
    int INum=0;
    float ang=car_now_angle;

//distance(m) & angle(rad) !!!!

   for (int i=0; i<32400; i++)
    {
        It_lidar[i]=-5;
    }

    for (unsigned i = 0; i < 361; ++i)  // 361 -> resol4 ((angle_max-angle_min)/increment)
    {llar[i] = scan->ranges[i];

    NumX[i]=floor((llar[i]*cos(resol2+3.141+resol1*i)))-6; //(n)
    NumY[i]=floor((llar[i]*sin(resol2+3.141+resol1*i))); //(m)

    int k1=round(cos(-ang)*(NumX[i])-sin(-ang)*(NumY[i]))+36/0.4;
    int k2=round(sin(-ang)*(NumX[i])+cos(-ang)*(NumY[i]))+36/0.4;

    INum=(180-k1+1)+180*(180-k2);
        It_lidar[INum] = 5;
    }


   Position newPosition = Position(car_now_y,car_now_x);
   map_.setPosition(newPosition);
// moving!!

   unsigned i=0;
   for (grid_map::GridMapIterator it(map_); !it.isPastEnd(); ++it)
   {if(i!=32400)
{ Position position;
 map_.getPosition(*it, position);
    map_.at("elevation_laser", *it) = It_lidar[i];
    i++;
       }

       else
       {
           break;}
   }
   // Publish as grid map.
   map_.setTimestamp(time.toNSec());
   grid_map_msgs::GridMap message;
   grid_map::GridMapRosConverter::toMessage(map_, message);
 //toMessage(map name==map_, message name);
   gridMapPublisher_.publish(message);
}


//occupancy
void KongTest::OCallback(const VPointCloud::ConstPtr &scan)
{
//ROS_INFO("Occupancy_callback run!");
  if (!mapInitialized_) {
    occu_.header.stamp = scan->header.stamp;
    occu_.header.frame_id = scan->header.frame_id; //frame_id -> velodyne

    map_.setGeometry(grid_map::Length(72, 72), 0.4);
    ROS_INFO("Initialized map with size %f x %f m (%i x %i cells).", map_.getLength().x(),
             map_.getLength().y(), map_.getSize()(0), map_.getSize()(1));
    mapInitialized_ = true;
  }


 ros::Time time = ros::Time::now();

  size_t npoints = scan->points.size();
  occu_.points.resize(npoints);


//  std::cout<<npoints<<std::endl;

  float ooar[32400];
  float ffar1[180][180];
  float wfar1[180][180];
  float ang=car_now_angle;

    for (int i = 0; i < 32400; i++) {
        ooar[i] = -5;
//         ooar[125*(124-(i%125))+125-(i/125)] = scan->points[i].z;
         }
      for (int i=0; i<125; i++)
      {
          for (int j=0; j<125; j++)
          {
 ffar1[i+27][j+27]=scan->points[i*125+j].z;
          }
      }
ffar1[89][89]=5;
ffar1[89][90]=5;
ffar1[90][89]=5;
ffar1[90][90]=5;

 for (int i=0; i<125; i++)
      {
          for (int j=0; j<125; j++)
          {

 int k1=round(cos(ang)*(i+27+1-90-0.5)-sin(ang)*(j+27+1-90-0.5)+90+0.5);
 int k2=round(sin(ang)*(i+27+1-90-0.5)+cos(ang)*(j+27+1-90-0.5)+90+0.5);


// wfar1[k1][k2]=ffar1[j+27][i+27];
    wfar1[k1][k2]=ffar1[j+27][i+27];
    ooar[(k1)*180+k2]=wfar1[k1][k2];
          }
      }

  unsigned i=0;
//   std::cout<<npoints<<std::endl;
  for (grid_map::GridMapIterator it(map_); !it.isPastEnd(); ++it)
  {if(i!=32400)
{ Position position;
map_.getPosition(*it, position);
map_.at("elevation_free", *it) = ooar[i]*3;
//  map_.at("elevation_free", *it) = 1;

   i++;
      }

      else
      {break;}
  }
/*
  for (GridMapIterator it(map_); !it.isPastEnd(); ++it) {
    Position position;
    map_.getPosition(*it, position);

    Eigen::Vector3d normal(1, 1, 1);
    normal.normalize();
    map_.at("normal_x", *it) = normal.x();
    map_.at("normal_y", *it) = normal.y();
    map_.at("normal_z", *it) = normal.z();
  }
  */
//   std::cout<<i<<std::endl;
  // Publish as grid map.
  map_.setTimestamp(time.toNSec());
   grid_map_msgs::GridMap message;
   grid_map::GridMapRosConverter::toMessage(map_, message);
 //toMessage(map name==map_, message name);
   gridMapPublisher_.publish(message);

}

} /* namespace */
