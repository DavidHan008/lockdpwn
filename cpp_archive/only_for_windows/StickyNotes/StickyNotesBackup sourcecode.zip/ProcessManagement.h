
#pragma once

extern int GetTimeStr (char timeStr[]);
extern bool FindProcess(CString processName);
extern bool KillProcess(CString processName);
extern bool StartProcess(CString m_Process);

